package com.example.udacityquiz;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText editText;
    // Declare your variables.
    private int mark, mark2, mark3, mark4, mark5;

    /**
     * @return - The total marks for all questions.
     */
    public int getTotalMarks() {
        return mark + mark2 + mark3 + mark4 + mark5;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
        editText = findViewById( R.id.answer_edit_text );
        //Attach Text listener for the edit text
        editText.addTextChangedListener( new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                String typeAnswer = editText.getText().toString();
                //Create a condition for the answer between the correct and the incorrect
                if (typeAnswer.equals( "wuhan" )) {
                    // Add 1 for the correct answer
                    mark3 = 1;
                    // Print a Toast message
                    // Return the mark with in the question 3
                    Toast.makeText( MainActivity.this, "Good"
                            , Toast.LENGTH_SHORT ).show();
                } else {
                    // Add 0 for the incorrect
                    mark3 = 0;
                }

            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        } );

    }

    /**
     * First question
     */
    public void onCheckboxClicked(View view) {
        // Reference checkbox views by ID
        CheckBox checkBox1 = findViewById( R.id.check_box_one );
        CheckBox checkBox2 = findViewById( R.id.check_box_two );
        CheckBox checkBox3 = findViewById( R.id.check_box_three );
        CheckBox checkBox4 = findViewById( R.id.check_box_four );
        //Create a condition if a view is checked
        if (checkBox1.isChecked() & checkBox4.isChecked()) {
            // Add 1 for correct answer
            // Do not increment++ rather equals 1
            // The logic will increment each time so we do not need it here
            mark = 1;
            // Disable buttons by a pair of 2
            checkBox2.setEnabled( false );
            checkBox3.setEnabled( false );
            // Create a Toast message when the answer is correct
            Toast.makeText( MainActivity.this, "Good"
                    , Toast.LENGTH_SHORT ).show();
        }
        //Create a condition if a view is checked
        if (checkBox1.isChecked() & checkBox2.isChecked()) {
            // Add 0 for incorrect answer
            mark = 0;
            // Disable buttons by a pair of 2
            checkBox3.setEnabled( false );
            checkBox4.setEnabled( false );
            // Create a Toast message when the answer is incorrect
            Toast.makeText( MainActivity.this, "Nope"
                    , Toast.LENGTH_SHORT ).show();
        }
        //Create a condition if a view is checked
        if (checkBox3.isChecked() & checkBox4.isChecked()) {
            // Add 0 for incorrect answer
            mark = 0;
            // Disable buttons by a pair of 2
            checkBox1.setEnabled( false );
            checkBox2.setEnabled( false );
            // Create a Toast message when the answer is incorrect
            Toast.makeText( MainActivity.this, "Nope"
                    , Toast.LENGTH_SHORT ).show();
        }
        //Create a condition if a view is checked
        if (checkBox1.isChecked() & checkBox3.isChecked()) {
            // Add 0 for incorrect answer
            mark = 0;
            // Disable buttons by a pair of 2
            checkBox2.setEnabled( false );
            checkBox4.setEnabled( false );
            // Create a Toast message when the answer is incorrect
            Toast.makeText( MainActivity.this, "Nope"
                    , Toast.LENGTH_SHORT ).show();
        }
        //Create a condition if a view is checked
        if (checkBox2.isChecked() & checkBox3.isChecked()) {
            // Add 0 for incorrect answer
            mark = 0;
            // Disable buttons by a pair of 2
            checkBox1.setEnabled( false );
            checkBox4.setEnabled( false );
            // Create a Toast message when the answer is incorrect
            Toast.makeText( MainActivity.this, "Nope"
                    , Toast.LENGTH_SHORT ).show();
        }
        //Create a condition if a view is checked
        if (checkBox2.isChecked() & checkBox4.isChecked()) {
            // Add 0 for incorrect answer
            mark = 0;
            // Disable buttons by a pair of 2
            checkBox1.setEnabled( false );
            checkBox3.setEnabled( false );
            // Create a Toast message when the answer is incorrect
            Toast.makeText( MainActivity.this, "Nope"
                    , Toast.LENGTH_SHORT ).show();
        }
    }

    /**
     * Second question.
     */
    public void onRadioButtonClicked(View view) {
        // Create a boolean to check whether a view is checked or not
        boolean checked2 = ((RadioButton) view).isChecked();
        //Switch your views by ID
        switch (view.getId()) {
            // Isolate the view that has the correct answer
            case R.id.radio_two:
                //Create a condition if a view is checked
                if (checked2)
                    // Add 1 for correct answer
                    // Do not increment++ rather equals 1
                    // The logic will increment each time so we do not need it here
                    mark2 = 1;
                // Create a Toast message when the answer is correct
                Toast.makeText( MainActivity.this, "Good "
                        , Toast.LENGTH_SHORT ).show();
                break;
            // Merge all the views that have to do with the incorrect answers
            case R.id.radio_one:
            case R.id.radio_three:
            case R.id.radio_four:
                if (checked2)
                    // Add 0 for incorrect answer
                    mark2 = 0;
                // Create No toast for the sake of not giving away the answer

                break;
        }
    }

    /**
     * fourth question.
     */
    public void onRadioButtonClickedTwo(View view) {
        // Create a boolean to check whether a view is checked or not
        boolean checked3 = ((RadioButton) view).isChecked();
        //Switch your views by ID
        switch (view.getId()) {
            // Isolate the view that has the correct answer
            case R.id.radio_one_of_two:
                if (checked3)
                    // Add 1 for correct answer
                    // Do not increment++ rather equals 1
                    // The logic will increment each time so we do not need it here
                    mark4 = 1;
                // Create a Toast message when the answer is correct
                Toast.makeText( MainActivity.this, "Good", Toast.LENGTH_SHORT ).show();
                break;
            // Merge all the views that have to do with the incorrect answers
            case R.id.radio_two_of_two:
            case R.id.radio_three_of_two:
            case R.id.radio_four_of_two:
                if (checked3)
                    // Add 0 for incorrect answer
                    mark4 = 0;
                // Create No toast for the sake of not giving away the answer
                break;
        }
    }

    /**
     * fifth question.
     */
    public void onCheckboxClickedTwo(View view) {
        // Reference checkbox views by ID
        CheckBox checkBox1oF2 = findViewById( R.id.check_box_one_of_two );
        CheckBox checkBox2oF2 = findViewById( R.id.check_box_two_of_two );
        CheckBox checkBox3oF2 = findViewById( R.id.check_box_three_of_two );
        CheckBox checkBox4oF2 = findViewById( R.id.check_box_four_of_two );
        //Create a condition if a view is checked
        if (checkBox3oF2.isChecked() & checkBox4oF2.isChecked()) {
            // Add 1 for correct answer
            // Do not increment++ rather equals 1
            // The logic will increment each time so we do not need it here
            mark5 = 1;
            // Disable buttons by a pair of 2
            checkBox1oF2.setEnabled( false );
            checkBox2oF2.setEnabled( false );
            // Create a Toast message when the answer is correct
            Toast.makeText( MainActivity.this, "Good"
                    , Toast.LENGTH_SHORT ).show();
        }
        //Create a condition if a view is checked
        if (checkBox1oF2.isChecked() & checkBox3oF2.isChecked()) {
            // Add 0 for incorrect answer
            mark5 = 0;
            // Disable buttons by a pair of 2
            checkBox2oF2.setEnabled( false );
            checkBox4oF2.setEnabled( false );
            // Create a Toast message when the answer is incorrect
            Toast.makeText( MainActivity.this, "Nope"
                    , Toast.LENGTH_SHORT ).show();
        }
        //Create a condition if a view is checked
        if (checkBox1oF2.isChecked() & checkBox4oF2.isChecked()) {
            // Add 0 for incorrect answer
            mark5 = 0;
            // Disable buttons by a pair of 2
            checkBox2oF2.setEnabled( false );
            checkBox3oF2.setEnabled( false );
            // Create a Toast message when the answer is incorrect
            Toast.makeText( MainActivity.this, "Nope"
                    , Toast.LENGTH_SHORT ).show();
        }
        //Create a condition if a view is checked
        if (checkBox2oF2.isChecked() & checkBox3oF2.isChecked()) {
            // Add 0 for incorrect answer
            mark5 = 0;
            // Disable buttons by a pair of 2
            checkBox1oF2.setEnabled( false );
            checkBox4oF2.setEnabled( false );
            // Create a Toast message when the answer is incorrect
            Toast.makeText( MainActivity.this, "Nope"
                    , Toast.LENGTH_SHORT ).show();
        }
        //Create a condition if a view is checked
        if (checkBox1oF2.isChecked() & checkBox2oF2.isChecked()) {
            // Add 0 for incorrect answer
            mark5 = 0;
            // Disable buttons by a pair of 2
            checkBox3oF2.setEnabled( false );
            checkBox4oF2.setEnabled( false );
            // Create a Toast message when the answer is incorrect
            Toast.makeText( MainActivity.this, "Nope"
                    , Toast.LENGTH_SHORT ).show();
        }
        //Create a condition if a view is checked
        if (checkBox2oF2.isChecked() & checkBox4oF2.isChecked()) {
            // Add 0 for incorrect answer
            mark5 = 0;
            // Disable buttons by a pair of 2
            checkBox1oF2.setEnabled( false );
            checkBox3oF2.setEnabled( false );
            // Create a Toast message when the answer is incorrect
            Toast.makeText( MainActivity.this, "Nope"
                    , Toast.LENGTH_SHORT ).show();
        }
    }

    /**
     * Submit button - Total mark and restart the activity
     */
    public void buttonClick(View view) {
        //Call the intent to restart quiz
        Intent intent = new Intent( MainActivity.this, MainActivity.class );
        startActivity( intent );
        //Print a Toast message for the total marks
        Toast.makeText( MainActivity.this, "You score a Point of : "
                + getTotalMarks() + "/5", Toast.LENGTH_SHORT ).show();
        //Reference to the views in @Link xml
    }
}






